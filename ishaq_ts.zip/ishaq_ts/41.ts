function show_magicians(magicians: string[]) {
  for (let magician of magicians) {
    console.log(magician);
  }
}
const magicians = ["Bangali", "Baba Boss", "Pir Tha Tha", "Baba Mastana"];

show_magicians(magicians);
