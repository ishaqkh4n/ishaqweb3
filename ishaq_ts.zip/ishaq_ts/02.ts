let man: string = "Sheikh Mahir";

console.log(`Hello ${man}, where are you going today?`);
