// Tests for equality and inequality with strings
let myString = 'hello';
const isEqual = 'world';
console.log(myString == 'hello'); // true
console.log(isEqual == myString);
let isNotEqual = myString != 'world'; // true

// Tests using the lower case function
let myString2 = 'Hello World';
let isLowerCase = myString2.toLowerCase() == 'hello world'; // true
let isNotLowerCase = myString2.toLowerCase() == 'HELLO WORLD'; // false

// Numerical tests involving equality and inequality, greater than and less than, 
// greater than or equal to, and less than or equal to
let myNumber = 10;
let isEqualToNumber = myNumber == 10; // true
let isNotEqualToNumber = myNumber != 5; // true
let isGreaterThanNumber = myNumber > 5; // true
let isLessThanNumber = myNumber < 20; // true
let isGreaterThanOrEqualToNumber = myNumber >= 10; // true
let isLessThanOrEqualToNumber = myNumber <= 10; // true

// Tests using "and" and "or" operators
let a = true;
let b = false;
let isTrueAndFalse = a && b; // false
let isTrueOrFalse = a || b; // true
