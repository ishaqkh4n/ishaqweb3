function make_album(artist: string, title: string, tracks?: number): {[key: string]: any} {
  const album = {
    artist: artist,
    title: title
  };
  if (tracks) {
    album['tracks'] = tracks;
  }
  return album;
}

// call the function with different arguments and print the returned value
console.log(make_album("Junaid Jamshed", "Mera Dil")); // output: { artist: 'Arijit Singh', title: 'Love Aaj Kal' }
console.log(make_album("Al Muqit", "Nasheed", 14)); // output: { artist: 'Ed Sheeran', title: '÷ (Divide)', tracks: 12 }
console.log(make_album("Yaser", "BE", 8)); // output: { artist: 'BTS', title: 'BE', tracks: 8 }
