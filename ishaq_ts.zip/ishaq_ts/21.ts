interface Country {
    name: string;
    capital: string;
    population: number;
    language: string;
  }
  
  let usa: Country = {
    name: "United States of America",
    capital: "Washington, D.C.",
    population: 331000000,
    language: "English"
  };
  
  let mexico: Country = {
    name: "Mexico",
    capital: "Mexico City",
    population: 129000000,
    language: "Spanish"
  };
  
  console.log(usa);
  console.log(mexico);
  