// Create a variable called alien_color and assign it a value of 'green', 'yellow', or 'red'
var alien_color = 'green';
// Write an if statement to test whether the alien’s color is green. If it is, print a message that the player just earned 5 points.
if (alien_color === 'green') {
    console.log('Congratulations, you just earned 5 points!');
}
