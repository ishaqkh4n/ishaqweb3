let guestList: string[] = ['Agha', 'Saif', 'Adnan'];

for (let guest of guestList) {
  console.log(`Dear ${guest}, you are cordially invited to dinner.`);
}

console.log(`We are inviting ${guestList.length} people to dinner.`);
