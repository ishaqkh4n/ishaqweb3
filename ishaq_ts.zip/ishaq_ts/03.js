var hero = "Mahir Almuaiqly";
console.log("Lowercase: ".concat(hero.toLowerCase()));
console.log("Uppercase: ".concat(hero.toUpperCase()));
console.log("Titlecase: ".concat(hero.charAt(0).toUpperCase() + hero.slice(1)));
