var countries = ["USA", "Canada", "Mexico", "Brazil", "Argentina", "Peru"];
console.log(countries);
