var pizzaNames = ['Tandoori', 'Cheese', 'Tikka', 'Chicken Spicy'];
// print a sentence using the name of each pizza
for (var _i = 0, pizzaNames_1 = pizzaNames; _i < pizzaNames_1.length; _i++) {
    var pizza = pizzaNames_1[_i];
    console.log("I like ".concat(pizza, " pizza."));
}
// additional sentence expressing love for pizza
console.log("Pizza is very delicious food.");
console.log("I feel hungry while writing this phrase and thinking about Pizza.");
console.log("I really love pizza and this is nonsense!");
