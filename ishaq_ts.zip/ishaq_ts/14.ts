const guests: string[] = ["Agha", "Saif", "Adnan"];

for (let i = 0; i < guests.length; i++) {
  console.log(`Dear ${guests[i]}, you are cordially invited to a dinner party at my place next Friday. Please let me know if you can attend.`);
}
