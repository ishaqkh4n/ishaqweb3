var person = "Sheikh Mahir";
console.log("Hello ".concat(person, ", where are you going today?"));
