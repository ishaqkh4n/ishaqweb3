function city_country(city, country) {
    return "".concat(city, ", ").concat(country);
}
// call the function with different arguments and print the result
console.log(city_country("Lahore", "Pakistan")); // output: Lahore, Pakistan
console.log(city_country("Berlin", "Germany")); // output: Barcelona, Spain
console.log(city_country("Istanbul", "Turkey")); // output: Sydney, Australia
