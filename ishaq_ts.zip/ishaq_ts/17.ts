// Define the original guest list
let guests: string[] = ["Agha", "Saif", "Adnan"];

// Print invitation messages for each guest
guests.forEach(guest => {
  console.log(`Dear ${guest}, you are cordially invited to dinner at my place.`);
});

// Replace a guest with a new guest
const guestUnableToAttend = "Saif";
const newGuest = "Hassan";
const index = guests.indexOf(guestUnableToAttend);
if (index !== -1) {
  guests[index] = newGuest;
  console.log(`${guestUnableToAttend} is unable to attend the dinner.`);
  console.log(`Instead, we have invited ${newGuest} to the dinner.`);
}

// Inform guests about the bigger dinner table
console.log("Great news! We just found a bigger dinner table!");

// Add three more guests to the guest list
guests.unshift("Syed"); // Add a guest to the beginning
guests.splice(Math.ceil(guests.length / 2), 0, "Zaynab"); // Add a guest to the middle
guests.push("Syeda"); // Add a guest to the end using push()

// Print invitation messages for the updated guest list
guests.forEach(guest => {
  console.log(`Dear ${guest}, you are still invited to dinner at my place.`);
});


console.log("I'm sorry to inform you that we can only invite two people for dinner.");

while (guests.length > 2) {
  let removedGuest = guests.pop();
  console.log(`Sorry, ${removedGuest}. There is no longer room at the table.`);
}

for (let guest of guests) {
  console.log(`Dear ${guest}, you're still invited to dinner tonight!`);
}

guests.pop();
guests.pop();

console.log(guests); // should output []
