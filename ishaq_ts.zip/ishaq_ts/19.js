var guestList = ['Agha', 'Saif', 'Adnan'];
for (var _i = 0, guestList_1 = guestList; _i < guestList_1.length; _i++) {
    var guest = guestList_1[_i];
    console.log("Dear ".concat(guest, ", you are cordially invited to dinner."));
}
console.log("We are inviting ".concat(guestList.length, " people to dinner."));
