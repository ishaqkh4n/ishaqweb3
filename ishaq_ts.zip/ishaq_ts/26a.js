// Create a variable called alien_color and assign it a value of 'green', 'yellow', or 'red'
var alien = 'red';
// If the alien’s color is green, print a statement that the player just earned 5 points for shooting the alien.
// If the alien’s color isn’t green, print a statement that the player just earned 10 points.
if (alien === 'green') {
    console.log('Congratulations, you just earned 5 points for shooting the alien!');
}
else {
    console.log('Congratulations, you just earned 10 points for shooting the alien!');
}
