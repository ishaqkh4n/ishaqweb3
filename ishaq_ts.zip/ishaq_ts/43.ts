function show_magicians(magicians: string[]) {
    for (let magician of magicians) {
      console.log(magician);
    }
  }
  
  function make_great(magicians: string[]): string[] {
  const greatMagicians: string[] = [];
  for (let i = 0; i < magicians.length; i++) {
    greatMagicians.push(`The Great ${magicians[i]}`);
  }
  return greatMagicians;
}
const magicians = ["Bangali", "Baba Boss", "Pir Tha Tha", "Baba Mastana"];

const greatMagicians = make_great([...magicians]);

show_magicians(magicians);
show_magicians(greatMagicians);
