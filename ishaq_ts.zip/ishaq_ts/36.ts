function make_shirt(size: string, message: string) {
  console.log(`The shirt is size ${size} and it says "${message}" on it.`);
}

// call the function with arguments
make_shirt("XL", "Smile, It's Sunnah! :)"); // output: The shirt is size XL and it says "Smile, It's Sunnah! :)" on it.
