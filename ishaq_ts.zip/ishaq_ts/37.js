function make_shirt(message, size) {
    if (message === void 0) { message = "I love TypeScript"; }
    if (size === void 0) { size = "L"; }
    console.log("The shirt is size ".concat(size, " and it says \"").concat(message, "\" on it."));
}
// create a large shirt with default message
make_shirt(); // output: The shirt is size L and it says "I love TypeScript" on it.
// create a medium shirt with default message
make_shirt("I also love JavaScript", "M"); // output: The shirt is size M and it says "I also love JavaScript" on it.
// create a custom shirt with different message and size
make_shirt("TypeScript is awesome!", "S"); // output: The shirt is size S and it says "TypeScript is awesome!" on it.
