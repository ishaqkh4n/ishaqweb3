var FavNum = 7;
var msg = "My favorite number is ".concat(FavNum, ".");
console.log(msg);
