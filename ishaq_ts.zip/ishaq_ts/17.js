// Define the original guest list
var guests = ["Agha", "Saif", "Adnan"];
// Print invitation messages for each guest
guests.forEach(function (guest) {
    console.log("Dear ".concat(guest, ", you are cordially invited to dinner at my place."));
});
// Replace a guest with a new guest
var guestUnableToAttend = "Saif";
var newGuest = "Hassan";
var index = guests.indexOf(guestUnableToAttend);
if (index !== -1) {
    guests[index] = newGuest;
    console.log("".concat(guestUnableToAttend, " is unable to attend the dinner."));
    console.log("Instead, we have invited ".concat(newGuest, " to the dinner."));
}
// Inform guests about the bigger dinner table
console.log("Great news! We just found a bigger dinner table!");
// Add three more guests to the guest list
guests.unshift("Syed"); // Add a guest to the beginning
guests.splice(Math.ceil(guests.length / 2), 0, "Zaynab"); // Add a guest to the middle
guests.push("Syeda"); // Add a guest to the end using push()
// Print invitation messages for the updated guest list
guests.forEach(function (guest) {
    console.log("Dear ".concat(guest, ", you are still invited to dinner at my place."));
});
console.log("I'm sorry to inform you that we can only invite two people for dinner.");
while (guests.length > 2) {
    var removedGuest = guests.pop();
    console.log("Sorry, ".concat(removedGuest, ". There is no longer room at the table."));
}
for (var _i = 0, guests_1 = guests; _i < guests_1.length; _i++) {
    var guest = guests_1[_i];
    console.log("Dear ".concat(guest, ", you're still invited to dinner tonight!"));
}
guests.pop();
guests.pop();
console.log(guests); // should output []
