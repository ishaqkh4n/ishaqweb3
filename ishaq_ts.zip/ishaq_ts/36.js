function make_shirt(size, message) {
    console.log("The shirt is size ".concat(size, " and it says \"").concat(message, "\" on it."));
}
// call the function with arguments
make_shirt("XL", "Smile, It's Sunnah! :)"); // output: The shirt is size XL and it says "Smile, It's Sunnah! :)" on it.
