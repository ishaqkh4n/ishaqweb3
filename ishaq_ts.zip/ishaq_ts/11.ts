const names: string[] = ['Pakistan', 'Turkey', 'Afghanistan', 'Saudi Arabia'];

for (let i = 0; i < names.length; i++) {
  console.log(names[i]);
}
