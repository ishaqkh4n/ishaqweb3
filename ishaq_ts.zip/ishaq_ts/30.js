var userNames = ['admin', 'Ishaq', 'Mahir', 'Mary', 'Tahir'];
for (var _i = 0, userNames_1 = userNames; _i < userNames_1.length; _i++) {
    var name_1 = userNames_1[_i];
    if (name_1 === 'admin') {
        console.log("Hello ".concat(name_1, ", would you like to see a status report?"));
    }
    else {
        console.log("Hello ".concat(name_1, ", thank you for logging in again."));
    }
}
