var usa = {
    name: "United States of America",
    capital: "Washington, D.C.",
    population: 331000000,
    language: "English"
};
var mexico = {
    name: "Mexico",
    capital: "Mexico City",
    population: 129000000,
    language: "Spanish"
};
console.log(usa);
console.log(mexico);
