var prophet = "Prophet Muhammad (PBUH)";
var hadith = "\"The best of you are those who learn the Qur'an and teach it.\"";
console.log("".concat(prophet, " said: ").concat(hadith, " "));
