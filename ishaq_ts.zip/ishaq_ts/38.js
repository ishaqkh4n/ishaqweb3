function describe_city(city, country) {
    if (country === void 0) { country = "Pakistan"; }
    console.log("".concat(city, " is in ").concat(country, "."));
}
// call the function with arguments
describe_city("Karachi"); // output: Karachi is in Pakistan.
describe_city("Mecca", "KSA"); // output: New York is in USA.
describe_city("Dubai", "UAE"); // output: London is in UK.
