let car: string = 'subaru';
let age: number = 30;
let isSunny: boolean = true;

// Test 1: Is car equal to 'subaru'?
console.log("Test 1: Is car equal to 'subaru'? I predict true.");
console.log(car === 'subaru');

// Test 2: Is car equal to 'honda'?
console.log("Test 2: Is car equal to 'honda'? I predict false.");
console.log(car === 'honda');

// Test 3: Is age greater than or equal to 18?
console.log("Test 3: Is age greater than or equal to 18? I predict true.");
console.log(age >= 18);

// Test 4: Is age less than 21?
console.log("Test 4: Is age less than 21? I predict false.");
console.log(age < 21);

// Test 5: Is isSunny equal to true?
console.log("Test 5: Is isSunny equal to true? I predict true.");
console.log(isSunny === true);

// Test 6: Is isSunny equal to false?
console.log("Test 6: Is isSunny equal to false? I predict false.");
console.log(isSunny === false);

// Test 7: Is age equal to 30?
console.log("Test 7: Is age equal to 30? I predict true.");
console.log(age === 30);

// Test 8: Is car not equal to 'toyota'?
console.log("Test 8: Is car not equal to 'toyota'? I predict true.");
console.log(car !== 'toyota');

// Test 9: Is age less than or equal to 10?
console.log("Test 9: Is age less than or equal to 10? I predict false.");
console.log(age <= 10);

// Test 10: Is car equal to 'subaru' AND age is greater than or equal to 25?
console.log("Test 10: Is car equal to 'subaru' AND age is greater than or equal to 25? I predict false.");
console.log(car === 'subaru' && age >= 25);
