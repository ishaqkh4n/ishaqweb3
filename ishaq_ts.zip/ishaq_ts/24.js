// Tests for equality and inequality with strings
var myString = 'hello';
var isEqual = 'world';
console.log(myString == 'hello'); // true
console.log(isEqual == myString);
var isNotEqual = myString != 'world'; // true
// Tests using the lower case function
var myString2 = 'Hello World';
var isLowerCase = myString2.toLowerCase() == 'hello world'; // true
var isNotLowerCase = myString2.toLowerCase() == 'HELLO WORLD'; // false
// Numerical tests involving equality and inequality, greater than and less than, 
// greater than or equal to, and less than or equal to
var myNumber = 10;
var isEqualToNumber = myNumber == 10; // true
var isNotEqualToNumber = myNumber != 5; // true
var isGreaterThanNumber = myNumber > 5; // true
var isLessThanNumber = myNumber < 20; // true
var isGreaterThanOrEqualToNumber = myNumber >= 10; // true
var isLessThanOrEqualToNumber = myNumber <= 10; // true
// Tests using "and" and "or" operators
var a = true;
var b = false;
var isTrueAndFalse = a && b; // false
var isTrueOrFalse = a || b; // true
