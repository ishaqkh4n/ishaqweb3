// Define the guest list
let guests: string[] = ["Agha", "Saif", "Adnan"];

// Print invitation messages for each guest
guests.forEach(guest => {
  console.log(`Dear ${guest}, you are cordially invited to dinner at my place.`);
});

// Change the guest list
const guestUnableToAttend = "Saif";
const newGuest = "Hassan";
const index = guests.indexOf(guestUnableToAttend);
if (index !== -1) {
  guests[index] = newGuest;
  console.log(`${guestUnableToAttend} is unable to attend the dinner.`);
  console.log(`Instead, we have invited ${newGuest} to the dinner.`);
}

// Print invitation messages for the updated guest list
guests.forEach(guest => {
  console.log(`Dear ${guest}, you are still invited to dinner at my place.`);
});
