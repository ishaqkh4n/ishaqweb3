const names: string[] = ['Pakistan', 'Turkey', 'Afghanistan', 'Saudi Arabia'];

for (let i = 0; i < names.length; i++) {
  console.log(`hello ${names[i]} Welcome to 2023, Happy new year. `);
}
