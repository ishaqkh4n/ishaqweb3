function makeSandwich() {
    var ingredients = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        ingredients[_i] = arguments[_i];
    }
    console.log("Making a sandwich with ".concat(ingredients.join(", "), "."));
}
// Call the function with different numbers of arguments
makeSandwich("fish", "tomato", "mayo");
makeSandwich("turkey", "bacon", "steak");
makeSandwich("peanut butter", "ketchup");
