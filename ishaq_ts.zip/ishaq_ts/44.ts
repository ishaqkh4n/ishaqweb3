function makeSandwich(...ingredients: string[]) {
  console.log(`Making a sandwich with ${ingredients.join(", ")}.`);
}

// Call the function with different numbers of arguments
makeSandwich("fish", "tomato", "mayo");
makeSandwich("turkey", "bacon", "steak");
makeSandwich("peanut butter", "ketchup");
