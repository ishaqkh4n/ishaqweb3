var transportation = ["Honda motorcycle", "Tesla Model S", "Ford F-150"];
for (var i = 0; i < transportation.length; i++) {
    console.log("I would like to own a ".concat(transportation[i], "."));
}
