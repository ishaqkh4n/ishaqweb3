// Create an array of favorite fruits
var favoritefruits = ["apple", "banana", "orange"];
// Use independent if statements to check for specific fruits in the array
if (favoritefruits.includes("apple")) {
    console.log("I really like apples!");
}
if (favoritefruits.includes("banana")) {
    console.log("I really like bananas!");
}
if (favoritefruits.includes("orange")) {
    console.log("I like oranges!");
}
if (favoritefruits.includes("grape")) {
    console.log("I like grapes!");
}
if (favoritefruits.includes("watermelon")) {
    console.log("I really like watermelons!");
}
