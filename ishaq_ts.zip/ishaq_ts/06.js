var a = "\t  Mahir Almuaiqly  \n";
console.log("Name with whitespaces: " + a);
var strippedName = a.trim();
console.log("Name without whitespaces: " + strippedName);
