function describe_city(city: string, country = "Pakistan") {
  console.log(`${city} is in ${country}.`);
}

// call the function with arguments
describe_city("Karachi"); // output: Karachi is in Pakistan.
describe_city("Mecca", "KSA"); // output: New York is in USA.
describe_city("Dubai", "UAE"); // output: London is in UK.
