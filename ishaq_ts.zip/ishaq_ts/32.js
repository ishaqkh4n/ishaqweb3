var current_users = ['Ishaq', 'Sara', 'Bhai', 'Mahir', 'Taha'];
var new_users = ['Yahya', 'Boss', 'SARA', 'bhai', 'Shah'];
var _loop_1 = function (i) {
    var username = new_users[i];
    if (current_users.some(function (user) { return user.toLowerCase() === username.toLowerCase(); })) {
        console.log("Sorry, the username \"".concat(username, "\" is already taken. Please choose a different username."));
    }
    else {
        console.log("Congratulations, the username \"".concat(username, "\" is available!"));
    }
};
for (var i = 0; i < new_users.length; i++) {
    _loop_1(i);
}
