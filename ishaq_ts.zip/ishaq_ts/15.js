// Define the guest list
var guests = ["Agha", "Saif", "Adnan"];
// Print invitation messages for each guest
guests.forEach(function (guest) {
    console.log("Dear ".concat(guest, ", you are cordially invited to dinner at my place."));
});
// Change the guest list
var guestUnableToAttend = "Saif";
var newGuest = "Hassan";
var index = guests.indexOf(guestUnableToAttend);
if (index !== -1) {
    guests[index] = newGuest;
    console.log("".concat(guestUnableToAttend, " is unable to attend the dinner."));
    console.log("Instead, we have invited ".concat(newGuest, " to the dinner."));
}
// Print invitation messages for the updated guest list
guests.forEach(function (guest) {
    console.log("Dear ".concat(guest, ", you are still invited to dinner at my place."));
});
