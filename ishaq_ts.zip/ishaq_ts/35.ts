const animals: string[] = ['Tiger', 'Cheetah', 'Lion' , 'Leopard'];

// print animal names using a for loop
for (let i = 0; i < animals.length; i++) {
  console.log(animals[i]);
}

// print a statement about each animal
for (let animal of animals) {
  console.log(`A ${animal.toLowerCase()} is a wild predator.`);
}

// additional sentence about the common characteristic
console.log("Any of these animals would'nt make a great pet!");
console.log("Cheetah is the fastest runner of all.");
console.log("Lion is considered the King of wild.");
console.log("Tiger has strips on its skin.");
