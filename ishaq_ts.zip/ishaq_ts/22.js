var numbers = [1, 2, 3, 4, 5];
// Access the 5th element of the array
var fifthNumber = numbers[4];
console.log(fifthNumber);
