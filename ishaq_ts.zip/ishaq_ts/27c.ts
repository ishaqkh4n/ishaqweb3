// this program shows green alien shot 5 points
var alien = 'red';

if (alien === 'green') {
    console.log('Congratulations, you just earned 5 points for shooting the alien!');
}
else if (alien === 'yellow')

{
    console.log('Congratulations, you just earned 10 points for shooting the alien!');
}
else if (alien === 'red')
{
    console.log('Congratulations, you just earned 15 points for shooting the alien!');
}