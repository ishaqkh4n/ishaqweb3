let numbers: number[] = [1, 2, 3, 4, 5];

// Access the 5th element of the array
let fifthNumber = numbers[4];

console.log(fifthNumber);
