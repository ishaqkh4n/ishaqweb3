const current_users: string[] = ['Ishaq', 'Sara', 'Bhai', 'Mahir', 'Taha'];
const new_users: string[] = ['Yahya', 'Boss', 'SARA', 'bhai', 'Shah'];

for (let i = 0; i < new_users.length; i++) {
  const username: string = new_users[i];
  if (current_users.some(user => user.toLowerCase() === username.toLowerCase())) {
    console.log(`Sorry, the username "${username}" is already taken. Please choose a different username.`);
  } else {
    console.log(`Congratulations, the username "${username}" is available!`);
  }
}
