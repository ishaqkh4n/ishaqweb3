let hero: string = "Mahir Almuaiqly";

console.log(`Lowercase: ${hero.toLowerCase()}`);
console.log(`Uppercase: ${hero.toUpperCase()}`);
console.log(`Titlecase: ${hero.charAt(0).toUpperCase() + hero.slice(1)}`);
