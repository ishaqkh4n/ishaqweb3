var prophet: string;
prophet = "Prophet Muhammad (PBUH)";
var hadith: string;
hadith = "\"The best of you are those who learn the Qur'an and teach it.\"";

console.log(`${prophet} said: ${hadith} `);