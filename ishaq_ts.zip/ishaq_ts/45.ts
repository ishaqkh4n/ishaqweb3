interface CarInfo {
  manufacturer: string;
  model: string;
  [key: string]: any;
}

function carInfo(manufacturer: string, model: string, ...args: any[]): CarInfo {
  const car: CarInfo = {
    manufacturer,
    model,
    ...args.reduce((prev, curr) => ({ ...prev, ...curr }), {}),
  };

  return car;
}
const myCar = carInfo("Honda", "Civic", { color: "White" }, { autopilot: false });

console.log(myCar);
