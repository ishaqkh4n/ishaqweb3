// Addition
console.log(5 + 3); // Output: 8

// Subtraction
console.log(12 - 4); // Output: 8

// Multiplication
console.log(2 * 4); // Output: 8

// Division
console.log(16 / 2); // Output: 8
