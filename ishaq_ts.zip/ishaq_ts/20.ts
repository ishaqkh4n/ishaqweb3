let countries: string[] = ["USA", "Canada", "Mexico", "Brazil", "Argentina", "Peru"];

console.log(countries);
