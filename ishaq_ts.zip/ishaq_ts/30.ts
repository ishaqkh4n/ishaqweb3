const userNames: string[] = ['admin', 'Ishaq', 'Mahir', 'Mary', 'Tahir'];

for (const name of userNames) {
  if (name === 'admin') {
    console.log(`Hello ${name}, would you like to see a status report?`);
  } else {
    console.log(`Hello ${name}, thank you for logging in again.`);
  }
}
