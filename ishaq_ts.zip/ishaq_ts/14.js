var guests = ["Agha", "Saif", "Adnan"];
for (var i = 0; i < guests.length; i++) {
    console.log("Dear ".concat(guests[i], ", you are cordially invited to a dinner party at my place next Friday. Please let me know if you can attend."));
}
