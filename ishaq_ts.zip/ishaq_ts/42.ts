function show_magicians(magicians: string[]) {
    for (let magician of magicians) {
      console.log(magician);
    }
  }
  function make_great(magicians: string[]) {
    for (let i = 0; i < magicians.length; i++) {
      magicians[i] = `The Great ${magicians[i]}`;
    }
  }
  const magicians = ["Bangali", "Baba Boss", "Pir Tha Tha", "Baba Mastana"];

  make_great(magicians);
  show_magicians(magicians);
  