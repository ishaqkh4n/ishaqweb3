// Author: Muhammad Ishaq, Today is 14-Feb-2023
// This program stores a name and his qoute in diffrent veriables and then prints his name with his qoute inside qoutaion marks.
var prophet;
prophet = "Prophet Muhammad (PBUH)";
var hadith;
hadith = "\"The best of you are those who learn the Qur'an and teach it.\"";
console.log("".concat(prophet, " said: ").concat(hadith, " "));
