var FavNum: number = 7;
var msg: string = `My favorite number is ${FavNum}.`;
console.log(msg);
